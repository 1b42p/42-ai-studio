import {
  AbsoluteFill,
  Composition,
  Easing,
  Sequence,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

const colors = {
  ink: "#2a1710",
  cream: "#f5ead7",
  sand: "#d6b58b",
  copper: "#b9683a",
  espresso: "#5a2e20",
  sage: "#8b9b7b",
  warmWhite: "#fff8ec",
};

const Page = ({children}: {children: React.ReactNode}) => (
  <AbsoluteFill
    style={{
      overflow: "hidden",
      backgroundColor: colors.cream,
      color: colors.ink,
      fontFamily: "DejaVu Sans, Arial, sans-serif",
    }}
  >
    {children}
  </AbsoluteFill>
);

const Grain = ({light = false}: {light?: boolean}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        opacity: light ? 0.18 : 0.1,
        backgroundImage: `radial-gradient(circle at ${35 + Math.sin(frame / 80) * 4}% ${30 + Math.cos(frame / 95) * 4}%, rgba(255,255,255,0.28) 0 1px, transparent 1.5px), radial-gradient(circle at ${68 + Math.cos(frame / 65) * 5}% ${70 + Math.sin(frame / 78) * 3}%, rgba(42,23,16,0.14) 0 1px, transparent 1.5px)`,
        backgroundSize: "17px 17px, 23px 23px",
        mixBlendMode: "multiply",
      }}
    />
  );
};

const Eyebrow = ({children, light = false}: {children: React.ReactNode; light?: boolean}) => (
  <div
    style={{
      fontSize: 22,
      fontWeight: 700,
      letterSpacing: 5,
      textTransform: "uppercase",
      color: light ? colors.cream : colors.copper,
    }}
  >
    {children}
  </div>
);

const SceneNumber = ({number}: {number: string}) => (
  <div
    style={{
      position: "absolute",
      top: 76,
      right: 102,
      display: "flex",
      alignItems: "center",
      gap: 18,
      color: colors.copper,
      fontSize: 20,
      letterSpacing: 4,
      fontWeight: 700,
    }}
  >
    <span style={{width: 42, height: 2, backgroundColor: colors.copper}} />
    {number}
  </div>
);

const Bean = ({x, y, scale, rotate, delay, dark = false}: {x: number; y: number; scale: number; rotate: number; delay: number; dark?: boolean}) => {
  const frame = useCurrentFrame();
  const bob = Math.sin((frame + delay) / 24) * 7;
  const appear = interpolate(frame, [0, 36], [0.75, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <g transform={`translate(${x} ${y + bob}) rotate(${rotate}) scale(${scale * appear})`}>
      <ellipse cx="0" cy="0" rx="78" ry="112" fill={dark ? colors.ink : colors.espresso} />
      <path d="M -10 -91 C -45 -50 -42 48 -2 91 C 22 66 27 18 17 -34 C 12 -60 1 -77 -10 -91 Z" fill={dark ? "#6e3a28" : "#82482f"} opacity="0.9" />
      <path d="M 3 -95 C -19 -56 -13 39 5 93" fill="none" stroke="#d98c5d" strokeWidth="8" strokeLinecap="round" opacity="0.8" />
    </g>
  );
};

const SceneBeans = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <Page>
      <div style={{position: "absolute", inset: 0, background: "linear-gradient(125deg, #f6ecd9 0%, #ead3b1 52%, #c9966c 100%)"}} />
      <div style={{position: "absolute", width: 800, height: 800, borderRadius: "50%", right: -100, top: 120, backgroundColor: "rgba(255,248,236,0.27)", border: "1px solid rgba(90,46,32,0.16)"}} />
      <div style={{position: "absolute", width: 590, height: 590, borderRadius: "50%", right: 5, top: 225, border: "1px solid rgba(90,46,32,0.16)"}} />
      <SceneNumber number="01 / 03" />
      <div style={{position: "absolute", left: 120, top: 202, width: 730}}>
        <Eyebrow>Начало вкуса</Eyebrow>
        <div style={{height: 28}} />
        <h1 style={{margin: 0, fontSize: 128, lineHeight: 0.93, letterSpacing: -6, fontWeight: 800}}>Зерно.<br /><span style={{color: colors.copper}}>Характер.</span></h1>
        <div style={{height: 42}} />
        <p style={{margin: 0, width: 530, fontSize: 30, lineHeight: 1.35, color: "#674131"}}>Всё начинается с маленького зерна — и времени, которое раскрывает его аромат.</p>
      </div>
      <svg viewBox="0 0 900 700" style={{position: "absolute", right: 40, bottom: 40, width: 780, height: 610}}>
        <path d="M 420 590 C 470 430 600 350 790 335" fill="none" stroke={colors.copper} strokeWidth="2" opacity="0.4" strokeDasharray="7 12" />
        <Bean x={520} y={300} scale={1.55} rotate={-21} delay={0} />
        <Bean x={710} y={435} scale={0.92} rotate={22} delay={18} dark />
        <Bean x={315} y={495} scale={0.72} rotate={42} delay={34} />
        <Bean x={775} y={215} scale={0.52} rotate={-36} delay={52} dark />
        <circle cx="520" cy="300" r="215" fill="none" stroke={colors.warmWhite} strokeWidth="3" opacity="0.55" strokeDasharray="2 18" />
      </svg>
      <div style={{position: "absolute", left: 120, bottom: 80, display: "flex", alignItems: "center", gap: 16, color: colors.ink, fontSize: 20, letterSpacing: 2}}>
        <span style={{width: 54, height: 2, backgroundColor: colors.ink}} />
        <span>{String(Math.round((frame / fps) * 10) / 10).padStart(4, "0")} / 10.0</span>
      </div>
      <Grain />
    </Page>
  );
};

const Drop = ({x, y, delay}: {x: number; y: number; delay: number}) => {
  const frame = useCurrentFrame();
  const t = ((frame + delay) % 150) / 150;
  const dropY = y + t * 240;
  const opacity = interpolate(t, [0, 0.05, 0.75, 1], [0, 1, 1, 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return <ellipse cx={x} cy={dropY} rx={9 - t * 2} ry={18 - t * 7} fill="#d8a06b" opacity={opacity} />;
};

const SceneBrew = () => {
  const frame = useCurrentFrame();
  const kettleLift = interpolate(frame, [20, 80, 240, 310], [40, 0, 0, 32], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.2, 0.8, 0.2, 1)});
  const pulse = 1 + Math.sin(frame / 22) * 0.025;
  return (
    <Page>
      <div style={{position: "absolute", inset: 0, backgroundColor: colors.ink}} />
      <div style={{position: "absolute", inset: 0, background: "radial-gradient(circle at 72% 48%, #7a3e29 0%, #401f18 38%, #2a1710 78%)"}} />
      <SceneNumber number="02 / 03" />
      <div style={{position: "absolute", left: 120, top: 170, color: colors.cream, width: 630}}>
        <Eyebrow light>Ритм приготовления</Eyebrow>
        <div style={{height: 26}} />
        <h2 style={{fontSize: 112, lineHeight: 0.95, letterSpacing: -5, margin: 0, fontWeight: 800}}>Вода.<br /><span style={{color: "#d8a06b"}}>Пауза.</span></h2>
        <div style={{height: 36}} />
        <p style={{fontSize: 29, lineHeight: 1.4, color: "#e6c7a7", margin: 0, width: 510}}>Горячая вода проходит сквозь помол медленно — чтобы забрать только самое важное.</p>
      </div>
      <svg viewBox="0 0 950 820" style={{position: "absolute", width: 820, height: 705, right: 50, bottom: -5}}>
        <g transform={`translate(0 ${kettleLift})`}>
          <path d="M 280 260 C 300 135 430 92 565 146 C 684 193 700 320 645 420 L 615 475 L 302 475 L 272 420 C 250 370 255 310 280 260 Z" fill="#d7a66f" />
          <path d="M 302 270 C 338 170 500 145 608 235 C 651 270 664 343 632 402 L 604 445 L 314 445 L 289 403 C 270 360 275 312 302 270 Z" fill="#5a2e20" />
          <path d="M 310 286 C 358 207 505 191 596 252" fill="none" stroke="#f0c999" strokeWidth="10" strokeLinecap="round" opacity="0.7" />
          <path d="M 558 165 C 640 62 779 100 790 190 C 797 244 768 273 731 290" fill="none" stroke="#d7a66f" strokeWidth="32" strokeLinecap="round" />
          <path d="M 280 252 C 158 225 89 266 70 326 C 128 355 190 342 284 320" fill="#bd8050" />
          <path d="M 340 136 C 357 82 440 53 510 80" fill="none" stroke="#d7a66f" strokeWidth="22" strokeLinecap="round" />
          <path d="M 398 75 L 558 75" stroke="#2a1710" strokeWidth="12" strokeLinecap="round" />
          <path d="M 430 75 C 430 35 522 35 522 75" fill="none" stroke="#d7a66f" strokeWidth="18" />
        </g>
        <path d="M 382 485 C 430 440 520 440 570 485 L 540 684 L 412 684 Z" fill="#f5ead7" />
        <path d="M 412 510 C 450 490 500 490 540 510 L 530 548 L 423 548 Z" fill="#2f1710" />
        <path d="M 412 684 L 540 684" stroke="#d7a66f" strokeWidth="15" strokeLinecap="round" />
        <Drop x={435} y={435} delay={0} /><Drop x={470} y={420} delay={44} /><Drop x={505} y={430} delay={87} />
        <path d="M 427 545 C 453 565 505 565 529 545" fill="none" stroke="#d7a66f" strokeWidth="4" opacity="0.7" />
        <circle cx="475" cy="585" r={102 * pulse} fill="none" stroke="#d7a66f" strokeWidth="2" opacity="0.35" strokeDasharray="4 12" />
      </svg>
      <div style={{position: "absolute", left: 120, bottom: 76, color: "#d8a06b", fontSize: 20, letterSpacing: 2}}>МЕДЛЕННО — ЗНАЧИТ ГЛУБЖЕ</div>
      <Grain light />
    </Page>
  );
};

const Steam = ({x, delay, height}: {x: number; delay: number; height: number}) => {
  const frame = useCurrentFrame();
  const y = interpolate((frame + delay) % 180, [0, 180], [0, -height], {extrapolateRight: "clamp"});
  const opacity = interpolate((frame + delay) % 180, [0, 20, 130, 180], [0, 0.6, 0.25, 0], {extrapolateRight: "clamp"});
  return <path d={`M ${x} 610 C ${x - 50} ${570 + y / 3} ${x + 45} ${530 + y / 2} ${x - 5} ${480 + y}`} fill="none" stroke="#fff8ec" strokeWidth="12" strokeLinecap="round" opacity={opacity} />;
};

const SceneCup = () => {
  const frame = useCurrentFrame();
  const glow = 0.84 + Math.sin(frame / 30) * 0.08;
  return (
    <Page>
      <div style={{position: "absolute", inset: 0, background: "linear-gradient(145deg, #d9e0d1 0%, #b6c6ae 48%, #849a7b 100%)"}} />
      <div style={{position: "absolute", left: -180, top: -180, width: 760, height: 760, borderRadius: "50%", border: "1px solid rgba(42,23,16,0.15)"}} />
      <div style={{position: "absolute", right: -160, bottom: -280, width: 820, height: 820, borderRadius: "50%", border: "1px solid rgba(42,23,16,0.15)"}} />
      <SceneNumber number="03 / 03" />
      <div style={{position: "absolute", left: 120, top: 185, width: 680}}>
        <Eyebrow>Финал, который остаётся</Eyebrow>
        <div style={{height: 28}} />
        <h2 style={{fontSize: 112, lineHeight: 0.96, letterSpacing: -5, margin: 0, fontWeight: 800}}>Чашка.<br /><span style={{color: colors.sage}}>Ваш ритуал.</span></h2>
        <div style={{height: 42}} />
        <p style={{fontSize: 30, lineHeight: 1.38, color: "#334334", margin: 0, width: 510}}>Один глоток — и день звучит точнее. Найдите свои десять минут.</p>
      </div>
      <svg viewBox="0 0 900 780" style={{position: "absolute", width: 860, height: 740, right: 28, bottom: -20}}>
        <ellipse cx="465" cy="682" rx="330" ry="42" fill="#52664d" opacity="0.34" />
        <ellipse cx="465" cy="620" rx="218" ry="65" fill="#fff8ec" opacity={glow} />
        <path d="M 257 385 C 275 525 329 620 465 634 C 601 620 655 525 673 385 Z" fill="#fff8ec" />
        <ellipse cx="465" cy="385" rx="208" ry="66" fill="#fff8ec" />
        <ellipse cx="465" cy="390" rx="168" ry="45" fill="#3b1d16" />
        <ellipse cx="465" cy="380" rx="128" ry="22" fill="#6f3a26" opacity="0.65" />
        <path d="M 654 455 C 785 400 835 523 753 575 C 714 600 675 571 663 542" fill="none" stroke="#fff8ec" strokeWidth="38" strokeLinecap="round" />
        <path d="M 669 462 C 748 435 783 500 758 540" fill="none" stroke="#9daf94" strokeWidth="10" strokeLinecap="round" />
        <Steam x={410} delay={0} height={170} /><Steam x={477} delay={56} height={210} /><Steam x={536} delay={102} height={150} />
        <circle cx="465" cy="380" r="215" fill="none" stroke="#fff8ec" strokeWidth="3" opacity="0.4" strokeDasharray="2 17" />
      </svg>
      <div style={{position: "absolute", left: 120, bottom: 80, display: "flex", alignItems: "center", gap: 16, color: colors.ink, fontSize: 20, letterSpacing: 2}}>
        <span style={{width: 54, height: 2, backgroundColor: colors.ink}} />
        <span>СОЗДАНО ДЛЯ ПАУЗЫ</span>
      </div>
      <Grain />
    </Page>
  );
};

export const CoffeeJourney = () => {
  const {fps} = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: colors.cream}}>
      <Sequence from={0} durationInFrames={10 * fps} premountFor={1}>
        <SceneBeans />
      </Sequence>
      <Sequence from={10 * fps} durationInFrames={10 * fps} premountFor={1}>
        <SceneBrew />
      </Sequence>
      <Sequence from={20 * fps} durationInFrames={10 * fps} premountFor={1}>
        <SceneCup />
      </Sequence>
    </AbsoluteFill>
  );
};

export const RemotionRoot = () => (
  <Composition
    id="CoffeeJourney"
    component={CoffeeJourney}
    durationInFrames={30 * 30}
    fps={30}
    width={1920}
    height={1080}
    defaultProps={{}}
  />
);
